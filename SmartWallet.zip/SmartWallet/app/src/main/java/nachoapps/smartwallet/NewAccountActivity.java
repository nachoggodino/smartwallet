package nachoapps.smartwallet;

import android.content.Context;
import android.graphics.Color;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import nachoapps.smartwallet.classes.Account;
import nachoapps.smartwallet.classes.SmartWallet;

public class NewAccountActivity extends AppCompatActivity {

    final String FILENAME = "SAVED_SMART_WALLET";

    private Spinner currencySpinner;
    private EditText nameEdit, offsetEdit;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_account);

        Toolbar myChildToolbar = findViewById(R.id.toolbar);
        currencySpinner = findViewById(R.id.currency_spinner);
        nameEdit = findViewById(R.id.name_edit);
        offsetEdit = findViewById(R.id.offset_edit);

        setSupportActionBar(myChildToolbar);
        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.setDisplayHomeAsUpEnabled(true);
        }

        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.currency_array, R.layout.custom_simple_spinner_item);
        adapter.setDropDownViewResource(R.layout.custom_simple_spinner_dropdown_item);
        currencySpinner.setAdapter(adapter);
    }

    @Override
    public void onBackPressed() {
        finish();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.new_account_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.check_btn) {
            String[] currencyArray = getResources().getStringArray(R.array.currency_array);
            Account.Currency currency = Account.Currency.EURO;
            if(currencySpinner.getSelectedItem().toString().equals(currencyArray[0])){
                currency = Account.Currency.EURO;
            } else if (currencySpinner.getSelectedItem().toString().equals(currencyArray[1])){
                currency = Account.Currency.DOLLAR;
            } else if (currencySpinner.getSelectedItem().toString().equals(currencyArray[2])){
                currency = Account.Currency.POUND;
            }
            Account account = new Account(nameEdit.getText().toString(), Account.Kind.ACCOUNT, Double.parseDouble(offsetEdit.getText().toString()), currency, Color.BLACK);
            SmartWallet smartWallet = getStoredSmartWallet();
            smartWallet.addAccount(account);
            storeSmartWallet(smartWallet);
            finish();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    public int storeSmartWallet(SmartWallet smartWallet){

        FileOutputStream outputStream;
        try {
            outputStream = openFileOutput(FILENAME, Context.MODE_PRIVATE);
            outputStream.write(SmartWallet.serialize(smartWallet).getBytes());
            outputStream.close();
            return 0;
        } catch (Exception e) {
            e.printStackTrace();
            return -1;
        }
    }

    public SmartWallet getStoredSmartWallet(){

        FileInputStream inputStream = null;

        try {
            inputStream = openFileInput(FILENAME);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
            return null;
        }

        int character;
        StringBuilder serializedSWRecovered = new StringBuilder();

        try {
            if (inputStream != null) {
                while( (character = inputStream.read()) != -1){
                    serializedSWRecovered.append(Character.toString((char) character));
                }
                inputStream.close();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        return SmartWallet.deSerialize(serializedSWRecovered.toString());
    }
}
