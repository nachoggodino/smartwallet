package nachoapps.smartwallet.classes;

import android.graphics.Color;

import java.security.InvalidParameterException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class Account {

    public enum Kind {ACCOUNT, INCOME_CATEGORY, EXPENSE_CATEGORY}
    public enum Currency {EURO, DOLLAR, POUND}

    ////////////////////////////////////////////////////////////////////////////////////////////////
    //                                             FIELDS                                         //
    ////////////////////////////////////////////////////////////////////////////////////////////////

    private String name;
    private double currentMoney;
    private List<Movement> movements;
    private Kind kind;
    private Currency currency;
    private int color;

    //private String description;
    //private Color color;
    //private Icon icon;

    ////////////////////////////////////////////////////////////////////////////////////////////////
    //                                             CONSTRUCTORS                                   //
    ////////////////////////////////////////////////////////////////////////////////////////////////

    public Account (String name, Kind kind, double offsetMoney, Currency currency, int color){
        this.name = name;
        this.kind = kind;
        this.currentMoney = offsetMoney;
        this.currency = currency;
        this.color = color;
        movements = new ArrayList<>();
    }

    ////////////////////////////////////////////////////////////////////////////////////////////////
    //                                             GETTERS                                        //
    ////////////////////////////////////////////////////////////////////////////////////////////////

    public double getCurrentMoney() {
        return currentMoney;
    }

    public Kind getKind() {
        return kind;
    }

    public String getName() {
        return name;
    }

    public Currency getCurrency() {
        return currency;
    }

    public String getCurrencySymbol(){
        switch (this.currency){
            case EURO:
                return "€";
            case POUND:
                return "£";
            case DOLLAR:
                return "$";
        }
        return "NO_SYMBOL";
    }

    public int getColor() {
        return color;
    }

    ////////////////////////////////////////////////////////////////////////////////////////////////
    //                                             SETTERS                                        //
    ////////////////////////////////////////////////////////////////////////////////////////////////

    public void addMoney(double amount){
        this.currentMoney += amount;
    }

    public void substractMoney(double amount){
        this.currentMoney -= amount;
    }

    public void addMovement(Movement movement){
        //Probablemente harán falta en orden cronólogico.
        this.movements.add(movement);
    }

    ////////////////////////////////////////////////////////////////////////////////////////////////
    //                                             METHODS                                        //
    ////////////////////////////////////////////////////////////////////////////////////////////////

    public double getIncomeExpenseResultBetweenTwoDates(Calendar startDate, Calendar endDate) throws Exception {
        if(startDate.after(endDate) || ( (this.kind != Kind.EXPENSE_CATEGORY) && (this.kind != Kind.INCOME_CATEGORY) ) ) {
            throw new InvalidParameterException("Puede ser por las fechas y su orden o porque intentas ejecutar el método en una cuenta que no es de gastos o ingresos.");
        }

        double result = 0;

        for (Movement movement : movements){
            if (movement.getDate().after(startDate) && movement.getDate().before(endDate)){
                result += movement.getAmount();
            }
        }
        return result;
    }

    public double getIncomeExpensesOfCurrentMonth() throws Exception {
        Calendar firstDayOfMonth = Calendar.getInstance();
        firstDayOfMonth.set(Calendar.DAY_OF_MONTH, 1);

        Calendar lastDayOfMonth = Calendar.getInstance();
        firstDayOfMonth.set(Calendar.DAY_OF_MONTH, firstDayOfMonth.getActualMaximum(Calendar.MONTH));

        return getIncomeExpenseResultBetweenTwoDates(firstDayOfMonth, lastDayOfMonth);
    }

    ////////////////////////////////////////////////////////////////////////////////////////////////
    //                                             PRIVATE                                        //
    ////////////////////////////////////////////////////////////////////////////////////////////////



}
