package nachoapps.smartwallet;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.util.Log;
import android.view.View;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.PopupMenu;
import android.widget.TextView;

import com.leinardi.android.speeddial.SpeedDialActionItem;
import com.leinardi.android.speeddial.SpeedDialView;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import nachoapps.smartwallet.classes.SmartWallet;

public class MainActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {

    final String FILENAME = "SAVED_SMART_WALLET";

    private SmartWallet smartWallet;

    private TextView textView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);

        //FAB
        SpeedDialView speedDialView = findViewById(R.id.fab);

        //DROPDOWNS
        Button dropdownMain = findViewById(R.id.dropdown_main);
        Button dropdownIncomeVsExpense = findViewById(R.id.dropdown_income_vs_expense);

        textView = findViewById(R.id.account_name);

        //FAB
        addFabItem(speedDialView, R.id.new_account, R.drawable.ic_bank_white_24dp, "Nueva cuenta");
        addFabItem(speedDialView, R.id.new_expense, R.drawable.ic_bank_transfer_out_white_24dp, "Añadir gasto", getResources().getColor(R.color.account1));
        addFabItem(speedDialView, R.id.new_transfer, R.drawable.ic_bank_transfer_white_24dp, "Nueva transferencia", getResources().getColor(R.color.colorAccent));
        addFabItem(speedDialView, R.id.new_income, R.drawable.ic_bank_transfer_in_white_24dp, "Añadir ingreso", getResources().getColor(R.color.account4));
        addFabItem(speedDialView, R.id.new_category, R.drawable.ic_category_white_24dp, "Nueva Categoría");

        speedDialView.setOnActionSelectedListener(fabListener);

        //NAVIGATION DRAWER
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();
        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);

        //LAYOUT LISTENERS
        dropdownMain.setOnClickListener(dropdownMainListener);
        dropdownIncomeVsExpense.setOnClickListener(dropdownIncomeVsExpensesListener);

        if(getStoredSmartWallet() == null){
            smartWallet = new SmartWallet();
        } else{
            smartWallet = getStoredSmartWallet();
        }
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        smartWallet = getStoredSmartWallet();
        updateLayout();
    }

    ////////////////////////////////////////////////////////////////////////////////////////////////
    //                                             CALLBACKS                                      //
    ////////////////////////////////////////////////////////////////////////////////////////////////

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.nav_home) {

        } else if (id == R.id.nav_accounts) {

        } else if (id == R.id.nav_expenses) {

        } else if (id == R.id.nav_income) {

        } else if (id == R.id.nav_settings) {

        } else if (id == R.id.nav_about) {

        }

        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }



    ////////////////////////////////////////////////////////////////////////////////////////////////
    //                                             LISTENERS                                      //
    ////////////////////////////////////////////////////////////////////////////////////////////////

    View.OnClickListener dropdownMainListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            PopupMenu popup = new PopupMenu(MainActivity.this, v);

            popup.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                @Override
                public boolean onMenuItemClick(MenuItem item) {
                    switch (item.getItemId()) {
                        case R.id.seven_days:
                            return true;
                        case R.id.thirty_days:
                            return true;
                        case R.id.year_days:
                            return true;
                        case R.id.custom_days:
                            return true;
                        default:
                            return false;
                    }
                }
            });
            popup.inflate(R.menu.compared_to_popup_menu);
            popup.show();
        }
    };

    View.OnClickListener dropdownIncomeVsExpensesListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            PopupMenu popup = new PopupMenu(MainActivity.this, v);

            popup.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                @Override
                public boolean onMenuItemClick(MenuItem item) {
                    switch (item.getItemId()) {
                        case R.id.seven_days:
                            return true;
                        case R.id.thirty_days:
                            return true;
                        case R.id.year_days:
                            return true;
                        case R.id.custom_days:
                            return true;
                        default:
                            return false;
                    }
                }
            });
            popup.inflate(R.menu.compared_to_popup_menu);
            popup.show();
        }
    };

    //FAB
    SpeedDialView.OnActionSelectedListener fabListener = new SpeedDialView.OnActionSelectedListener() {
        @Override
        public boolean onActionSelected(SpeedDialActionItem speedDialActionItem) {
            switch (speedDialActionItem.getId()) {
                case R.id.new_account:
                    Intent i = new Intent(MainActivity.this, NewAccountActivity.class);
                    startActivity(i);
                    return false; // true to keep the Speed Dial open
                case R.id.new_category:
                    return false;
                case R.id.new_expense:
                    return false;
                case R.id.new_income:
                    return false;
                case R.id.new_transfer:
                    return false;
                default:
                    return false;
            }
        }
    };

    ////////////////////////////////////////////////////////////////////////////////////////////////
    //                                             STORAGE                                        //
    ////////////////////////////////////////////////////////////////////////////////////////////////

    public int storeSmartWallet(SmartWallet smartWallet){

        FileOutputStream outputStream;
        try {
            outputStream = openFileOutput(FILENAME, Context.MODE_PRIVATE);
            outputStream.write(SmartWallet.serialize(smartWallet).getBytes());
            outputStream.close();
            return 0;
        } catch (Exception e) {
            e.printStackTrace();
            return -1;
        }
    }

    public SmartWallet getStoredSmartWallet(){

        FileInputStream inputStream = null;

        try {
            inputStream = openFileInput(FILENAME);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
            return null;
        }

        int character;
        StringBuilder serializedSWRecovered = new StringBuilder();

        try {
            if (inputStream != null) {
                while( (character = inputStream.read()) != -1){
                    serializedSWRecovered.append(Character.toString((char) character));
                }
                inputStream.close();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        return SmartWallet.deSerialize(serializedSWRecovered.toString());
    }



    ////////////////////////////////////////////////////////////////////////////////////////////////
    //                                             PRIVATE                                        //
    ////////////////////////////////////////////////////////////////////////////////////////////////

    private void addFabItem(SpeedDialView speedDialView, int id, int icon, String label){
        speedDialView.addActionItem(
                new SpeedDialActionItem.Builder(id, icon)
                        .setLabel(label)
                        .create()
        );
    }

    private void addFabItem(SpeedDialView speedDialView, int id, int icon, String label, int iconBackgroundColor){
        speedDialView.addActionItem(
                new SpeedDialActionItem.Builder(id, icon)
                        .setLabel(label)
                        .setFabBackgroundColor(iconBackgroundColor)
                        .create()
        );
    }

    private void updateLayout(){
        textView.setText(Integer.toString(smartWallet.getAccountsSize()));
    }

}
