package nachoapps.smartwallet.classes;

import android.content.Context;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.io.FileOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class SmartWallet implements Serializable {

    ////////////////////////////////////////////////////////////////////////////////////////////////
    //                                             FIELDS                                         //
    ////////////////////////////////////////////////////////////////////////////////////////////////

    private List<Account> accounts;
    private List<Account> incomeCategories;
    private List<Account> expenseCategories;
    private List<Movement> movements;

    ////////////////////////////////////////////////////////////////////////////////////////////////
    //                                             CONSTRUCTORS                                   //
    ////////////////////////////////////////////////////////////////////////////////////////////////

    public SmartWallet(){

        accounts = new ArrayList<>();
        incomeCategories = new ArrayList<>();
        expenseCategories = new ArrayList<>();

    }

    ////////////////////////////////////////////////////////////////////////////////////////////////
    //                                             GETTERS                                        //
    ////////////////////////////////////////////////////////////////////////////////////////////////

    public int getAccountsSize(){
        return accounts.size();
    }

    ////////////////////////////////////////////////////////////////////////////////////////////////
    //                                             SETTERS                                        //
    ////////////////////////////////////////////////////////////////////////////////////////////////



    ////////////////////////////////////////////////////////////////////////////////////////////////
    //                                             METHODS                                        //
    ////////////////////////////////////////////////////////////////////////////////////////////////

    public void addAccount(Account account){
        switch (account.getKind()){
            //Tal vez debería comprobar que no hay dos con el mismo nombre.
            case ACCOUNT:
                accounts.add(account);
            case EXPENSE_CATEGORY:
                expenseCategories.add(account);
            case INCOME_CATEGORY:
                incomeCategories.add(account);
        }
    }

    public void executeMovement(Movement movement){
        switch (movement.getKind()){
            case INCOME:
                Account originA = incomeCategories.get(movement.getOriginAccount());
                originA.addMoney(movement.getAmount());
                originA.addMovement(movement);

                Account destinationA = accounts.get(movement.getDestinationAccount());
                destinationA.addMoney(movement.getAmount());
                destinationA.addMovement(movement);
            case EXPENSE:
                Account originB = accounts.get(movement.getOriginAccount());
                originB.substractMoney(movement.getAmount());
                originB.addMovement(movement);

                Account destinationB = expenseCategories.get(movement.getDestinationAccount());
                destinationB.addMoney(movement.getAmount());
                destinationB.addMovement(movement);
            case TRANSFER:
                Account originC = accounts.get(movement.getOriginAccount());
                originC.substractMoney(movement.getAmount());
                originC.addMovement(movement);

                Account destinationC = accounts.get(movement.getDestinationAccount());
                destinationC.addMoney(movement.getAmount());
                destinationC.addMovement(movement);
        }
        movements.add(movement);

    }

    public double getTotalBalance(){
        double accountsResult = 0;
        for(Account account : this.accounts){
            accountsResult += account.getCurrentMoney();
        }
        return accountsResult;
    }

    public double getIncomeExpensesOfCurrentMonth() throws Exception {
        double result = 0;
        for (Account category : incomeCategories){
            result += category.getIncomeExpensesOfCurrentMonth();
        }
        for (Account category : expenseCategories){
            result += category.getIncomeExpensesOfCurrentMonth();
        }
        return result;
    }

    ////////////////////////////////////////////////////////////////////////////////////////////////
    //                                             PRIVATE                                        //
    ////////////////////////////////////////////////////////////////////////////////////////////////

    public static String serialize(SmartWallet smartWallet){
        Gson listJson = new Gson();
        return listJson.toJson(smartWallet);
    }

    public static SmartWallet deSerialize(String json){
        return new Gson().fromJson(json,
                new TypeToken<SmartWallet>(){}.getType());
    }

}
